<?php
/**
 * Add post views in a custom field
 */
function otakuhub_setpostviews( $postID ) {
    $count_key = 'post_views_count';
    $count = get_post_meta( $postID, $count_key, true );
    if( $count=='' ) {
        $count = 0;
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
    } else {
        $count++;
        update_post_meta( $postID, $count_key, $count );
    }
}
// To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

/**
 * Track post views in single posts
 */
function otakuhub_trackpostviews( $post_id ) {
    if ( !is_single() ) {
        return;
    }
    if ( empty ( $post_id ) ) {
        global $post;
        $post_id = $post->ID;    
    }
    otakuhub_setpostviews( $post_id );
}
// Add the tracker in the header by using wp_head hook
add_action('wp_head', 'otakuhub_trackpostviews');

/**
 * Display post views in single posts
 */
function otakuhub_getpostviews( $postID ) {
    $count_key = 'post_views_count';
    $count = get_post_meta( $postID, $count_key, true );
    if( $count=='' ) {
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
        return "0";
    }
    return $count;
}