<?php
/**
 * Register the post type Chapters
 */
function otakuhub_manga_type_chapters() {
    $labels = array(
        'name'                  => _x( 'Chapters', 'Post Type General Name', 'otakuhub-manga' ),
        'singular_name'         => _x( 'Chapter', 'Post Type Singular Name', 'otakuhub-manga' ),
        'menu_name'             => __( 'Chapters', 'otakuhub-manga' ),
        'name_admin_bar'        => __( 'Chapter', 'otakuhub-manga' ),
    );
    $rewrite = array(
        'slug'                  => 'manga/chapter',
        'with_front'            => true,
        'pages'                 => true,
        'feeds'                 => true,
    );
    $args = array(
        'label'                 => __( 'Chapter', 'otakuhub-manga' ),
        'description'           => __( 'My Chapters', 'otakuhub-manga' ),
        'labels'                => $labels,
        'supports'              => array( 'title' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-admin-page',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,		
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'rewrite'               => $rewrite,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type( 'chapters', $args );
}