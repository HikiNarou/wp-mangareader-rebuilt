<?php
/**
 * Site loop settings
 */
function otakuhub_manga_loop_settings( $query ) {
    global $wp_the_query;
    if ( $wp_the_query === $query ) {
        if ( ! is_admin() ) {
            if ( $query->is_main_query() && $query->is_home() ) {
                $query->set( 'post_type', array( 'chapters' ) );
            }
            
            if ( $query->is_main_query() && $query->is_feed) {
                $query->set( 'post_type', array( 'mangas' ) );
            }
            
            if ( $query->is_main_query() && $query->is_archive() ) {
                $query->set( 'post_type', array( 'mangas' ) );
            }
            
            if ( $query->is_main_query() && $query->is_tax('scanlators') ) {
                $query->set( 'post_type', array( 'chapters' ) );
            }
            
            if ( $query->is_main_query() && $query->is_search) {
                $query->set( 'post_type', array( 'mangas' ) );
            }
            
            if ( $query->is_main_query() && $query->is_search && $query->is_feed) {
                $query->set( 'post_type', array( 'chapters' ) );
            }
        }
    }
}