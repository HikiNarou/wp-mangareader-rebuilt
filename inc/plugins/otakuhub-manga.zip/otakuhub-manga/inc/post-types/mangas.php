<?php
/**
 * Register the post type Mangas
 */
function otakuhub_manga_type_mangas() {
    $labels = array(
        'name'                  => _x( 'Mangas', 'Post Type General Name', 'otakuhub-manga' ),
        'singular_name'         => _x( 'Manga', 'Post Type Singular Name', 'otakuhub-manga' ),
        'menu_name'             => __( 'Mangas', 'otakuhub-manga' ),
        'name_admin_bar'        => __( 'Manga', 'otakuhub-manga' ),
    );
    $rewrite = array(
        'slug'                  => 'manga',
        'with_front'            => true,
        'pages'                 => true,
        'feeds'                 => true,
    );
    $args = array(
        'label'                 => __( 'Manga', 'otakuhub-manga' ),
        'description'           => __( 'My Mangas', 'otakuhub-manga' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'thumbnail', 'comments', ),
        'taxonomies'            => array( 'category', 'post_tag', 'authors', 'artists' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-book-alt',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,		
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'rewrite'               => $rewrite,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type( 'mangas', $args );
}