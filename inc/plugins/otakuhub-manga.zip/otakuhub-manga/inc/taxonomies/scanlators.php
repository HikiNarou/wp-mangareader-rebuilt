<?php
/**
 * Register the taxonomy Scanlators
 */
function otakuhub_manga_taxes_scanlators() {
    $labels = array(
        'name'                       => _x( 'Scanlators', 'Taxonomy General Name', 'otakuhub-manga' ),
        'singular_name'              => _x( 'Scanlator', 'Taxonomy Singular Name', 'otakuhub-manga' ),
        'menu_name'                  => __( 'Scanlator', 'otakuhub-manga' ),
    );
    $rewrite = array(
        'slug'                       => 'scanlators',
        'with_front'                 => true,
        'hierarchical'               => false,
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'query_var'                  => 'scanlators',
        'has_archive'       		 => true,
        'rewrite'                    => $rewrite,
        'show_in_rest'               => true,
    );
    register_taxonomy( 'scanlators', array( 'chapters' ), $args );
}
