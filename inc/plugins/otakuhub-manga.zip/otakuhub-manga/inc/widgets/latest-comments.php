<?php
/**
 * Latest Comments Widget
 */
class otakuhub_manga_latestcomments_widget extends WP_Widget {
    function __construct() {
        parent::__construct(
            'otakuhub_manga_latestcomments_widget',
            __( 'Latest Comments', 'otakuhub-manga' ),
            array( 'description' => __( 'Adds a latest comments widget', 'otakuhub-manga' ), )
        );
    }
    
    public function widget( $args, $instance ) {
        if ( empty( $instance['title'] ) ) {
            $instance['title'] = __( 'Latest Comments', 'otakuhub-manga' );
		}
		
        if ( empty( $instance['items'] ) ) {
            $instance['items'] = 5;
        }		
		
        $title = apply_filters( 'widget_title', $instance['title'] );
        $items = apply_filters( 'widget_items', $instance['items'] );
		
        echo $args['before_widget'];            
            echo $args['before_title'];
                if ( ! empty( $title ) ) {
                    echo $title;
                } else {
                    _e( 'Latest Comments', 'otakuhub-manga' );
                }
            echo $args['after_title'];
            
            $comm = array (
                'status' => 'approve',
                'number' => $items
            );		
            $comments = get_comments( $comm );
            
            if ( ! empty( $comments ) ) {
            ?>
                <div class="sidebar-comments">
                    <?php
                    foreach( $comments as $comment ) {
                    ?>
                        <div class="uk-grid uk-grid-collapse uk-grid-match" data-uk-grid-margin>
                            <div class="uk-width-small-1-1">
                                <div class="uk-block uk-block-muted">
                                    <?php echo $comment->comment_content; ?>
                                    <br />
                                    <?php
                                    printf( wp_kses( __( '<p>By %1$s in <a href="%2$s#comment-%3$s">%4$s</a></p>', 'otakuhub-manga' ), array( 'a' => array( 'href' => array() ), 'p' => array(), ) ), $comment->comment_author, get_permalink($comment->comment_post_ID), $comment->comment_ID, get_the_title($comment->comment_post_ID) );
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            <?php
            }
        echo $args['after_widget'];
    }
    
    public function form( $instance ) {
        if ( isset( $instance[ 'title' ] ) ) {
            $title = $instance[ 'title' ];
        } else {
            $title = __( 'Latest Comments', 'otakuhub-manga' );
        }
        
        if ( isset( $instance[ 'items' ] ) ) {
            $items = $instance[ 'items' ];
        } else {
            $items = 5;
        }
        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>">
                <?php _e( 'Title:', 'otakuhub-manga' ); ?>
            </label> 
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id( 'items' ); ?>">
                <?php _e( 'Show:', 'otakuhub-manga' ); ?>
            </label> 
            <input class="widefat" id="<?php echo $this->get_field_id( 'items' ); ?>" name="<?php echo $this->get_field_name( 'items' ); ?>" type="number" value="<?php echo esc_attr( $items ); ?>" />
        </p>
    <?php 
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['items'] = ( ! empty( $new_instance['items'] ) ) ? strip_tags( $new_instance['items'] ) : '';
        return $instance;
    }
}