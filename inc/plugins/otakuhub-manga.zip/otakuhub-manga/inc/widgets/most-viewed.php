<?php
/**
 * Most Viewed Widget
 */
class otakuhub_manga_mostviews_widget extends WP_Widget {
    function __construct() {
        parent::__construct(
            'otakuhub_manga_mostviews_widget',
            __( 'Most Viewed Mangas', 'otakuhub-manga' ),
            array( 'description' => __( 'Adds a most viewed mangas widget', 'otakuhub-manga' ), ) 
        );
    }
 
    public function widget( $args, $instance ) {
        if ( empty( $instance['title'] ) ) {
            $instance['title'] = __( 'Most Viewed', 'otakuhub-manga' );
        }
        
        if ( empty( $instance['items'] ) ) {
            $instance['items'] = 5;
        }
        
        $title = apply_filters( 'widget_title', $instance['title'] ); 
        $items = apply_filters( 'widget_items', $instance['items'] );
        
        echo $args['before_widget'];        
            echo $args['before_title'];
            
                if ( ! empty( $title ) ) {
                    echo $title;
                } else {
                    _e( 'Most Viewed', 'otakuhub-manga' );
                }
            
            echo $args['after_title'];
            ?>
        	
            <div class="new-manga">
                <div class="uk-grid uk-grid-collapse uk-grid-match" data-uk-grid-margin>
                
                    <?php
                    $popularpost = new WP_Query( array(
                        'post_type' => 'mangas',
                        'posts_per_page' => $items,
                        'meta_key' => 'post_views_count',
                        'orderby' => 'meta_value_num',
                        'order' => 'DESC'
                    ) );
                
                    $top_manga = 1;
                
                    while ( $popularpost->have_posts() ) : $popularpost->the_post();
                    
                        $manga_chapters = get_posts( array(
                            'post_type' => 'chapters',
                            'meta_query' => array( array(
                                'key' => 'manga',
                                'value' => '"' . get_the_ID() . '"',
                                'compare' => 'LIKE'
                            ) )
                        ) );
                    
                        $post_slug = get_post_field( 'post_name' );
                        ?>
                    
                        <div class="uk-width-small-5-10 uk-width-medium-1-1">
                            <div class="uk-grid uk-grid-collapse uk-grid-match" data-uk-grid-margin>
                                <div class="uk-width-small-1-4 uk-width-xlarge-2-10">
                                    <div class="uk-block uk-block-muted uk-padding-remove">
                                        <a href="<?php the_permalink() ?>" class="uk-overlay" title="<?php the_title() ?>">
		                                    <?php the_post_thumbnail( 'thumbnail' ); ?>
                                            <div class="uk-overlay-panel"><?php echo $top_manga++ ?></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="uk-width-small-3-4 uk-width-xlarge-8-10">
                                    <div class="uk-block uk-block-muted uk-vertical-align">
                                        <div class="uk-vertical-align-middle">
                                            <a href="<?php the_permalink() ?>" title="<?php the_title() ?>">
                                                <?php the_title() ?>
                                            </a>
                                            <br />
                                            <?php
                                            if ( $manga_chapters ) {
                                                foreach ( $manga_chapters as $chapters ) {
                                                    echo '<a href="'.site_url().'/manga/'.$post_slug.'/'.$chapters->post_name.'">'.get_the_title( $chapters->ID ).'</a>';
                                                    break;
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    endwhile;
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        <?php
        echo $args['after_widget'];
    }
    
    public function form( $instance ) {
        if ( isset( $instance[ 'title' ] ) ) {
            $title = $instance[ 'title' ];
        } else {
            $title = __( 'Most Viewed', 'otakuhub-manga' );
        }
        
        if ( isset( $instance[ 'items' ] ) ) {
            $items = $instance[ 'items' ];
        } else {
            $items = 5;
        } ?>
            
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>">
                <?php _e( 'Title:', 'otakuhub-manga' ); ?>
            </label> 
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'items' ); ?>">
                <?php _e( 'Show:', 'otakuhub-manga' ); ?>
            </label> 
            <input class="widefat" id="<?php echo $this->get_field_id( 'items' ); ?>" name="<?php echo $this->get_field_name( 'items' ); ?>" type="number" value="<?php echo esc_attr( $items ); ?>" />
        </p>
    <?php 
    }
        
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['items'] = ( ! empty( $new_instance['items'] ) ) ? strip_tags( $new_instance['items'] ) : '';
        return $instance;
    }
}