<?php
/*
Plugin Name: OtakuHub Manga
Plugin URI: http://salamandr.space
Description: Plugin for the manga reader themes.
Version: 1.0.0
Author: Angel Castillo
Author URI: http://salamandr.space
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: otakuhub-manga
Domain Path: /languages/
*/

/**
 * Define filepath
 */
define( 'OHM_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Localization
 */
function otakuhub_load_textdomain() {
    load_plugin_textdomain( 'otakuhub-manga', false, basename( dirname( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'otakuhub_load_textdomain' );

/**
 * Load function files
 */
require ( OHM_PATH . 'inc/post-types/mangas.php' );
require ( OHM_PATH . 'inc/post-types/chapters.php' );
require ( OHM_PATH . 'inc/post-types/loop-settings.php' );
require ( OHM_PATH . 'inc/taxonomies/authors.php' );
require ( OHM_PATH . 'inc/taxonomies/artists.php' );
require ( OHM_PATH . 'inc/taxonomies/scanlators.php' );
require ( OHM_PATH . 'inc/widgets/welcome-box.php' );
require ( OHM_PATH . 'inc/widgets/most-viewed.php' );
require ( OHM_PATH . 'inc/widgets/latest-comments.php' );
require ( OHM_PATH . 'inc/addons/entry-views.php' );

/**
 * Initialize the types and taxes
 */
add_action( 'init', 'otakuhub_manga_type_mangas', 0 );
add_action( 'init', 'otakuhub_manga_type_chapters', 0 );
add_action( 'init', 'otakuhub_manga_taxes_artists', 0 );
add_action( 'init', 'otakuhub_manga_taxes_authors', 0 );
add_action( 'init', 'otakuhub_manga_taxes_scanlators', 0 );

/**
 * Add custom post types to loop
 */
add_action( 'pre_get_posts', 'otakuhub_manga_loop_settings' );

/**
 * Register and initialize the widgets
 */
function otakuhub_manga_register_widgets() {
    register_widget( 'otakuhub_manga_welcomebox_widget' );
    register_widget( 'otakuhub_manga_mostviews_widget' );
    register_widget( 'otakuhub_manga_latestcomments_widget' );
}
add_action( 'widgets_init', 'otakuhub_manga_register_widgets' );

/**
 * Post Type for Core Widgets
 *
 * Changes the post type used from post to mangas
 */
function mangastarter_post_type_widgets($params) {
   $params['post_type'] = array( 'mangas' );
   return $params;
}
add_filter('widget_posts_args', 'mangastarter_post_type_widgets');
add_filter('widget_comments_args', 'mangastarter_post_type_widgets'); 